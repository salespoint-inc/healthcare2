window.config = {
  BlobBaseUrl: "https://nrfcdn.azureedge.net/",
  IconBlobBaseUrl: "https://nrfcdn.azureedge.net/left-nav-icons/",

  // APIUrl: "https://app-nrf.azurewebsites.net",
  APIUrl: "https://app-midp2-with-azcosmosdb.azurewebsites.net/",
  // APIUrl: "https://localhost:5001",

  //CEO Dashboard DEC
  CEODashboardMayDashboardID: "5eaf24f2-0603-4dda-85ab-a128fb89e196",
  CEODashboardBeforeReportID: "f60fea96-d262-40e2-8150-3380b1e075d7",
  CEODashboardBeforeReportName: "ReportSection5f752c6bde03670c8284",

  //ADX Report New York 8 AM
  ADXDirectReportReportID: "9991e50c-4afc-45f4-8e23-6dca27fa6270",
  ADXDirectReportReportSectionName: "ReportSectionb4cd1d334fe3b8497487",

  //Power Apps
  PowerApps:
    "https://apps.powerapps.com/play/619f6853-114b-4faf-817b-895668b614d3?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",

  //World Map
  WorldMapReportID: "21449c54-98f8-4870-92d5-a396629841aa",
  WorldMapReportSectionName: "ReportSection",
  //Revenue and Customer Churn
  RevenueAndCustomerChurnReportID: "7a51b47d-76ca-4bc3-ba78-8b3f1317047a",
  RevenueAndCustomerChurnReportSectionName: "ReportSection",

  //Ceo Dashboard Dec
  CEODashboardAfterDashboardID: "3e2aeba9-d89a-4c93-92c6-ff9958c4ba50",
  CEODashboardAfterReportID: "f60fea96-d262-40e2-8150-3380b1e075d7",
  CEODashboardAfterReportSectionName: "ReportSection68cb8066934630a72b53",

  //Location Analytics
  LocationAnalyticsReportID: "be536a37-ebdb-4f36-9293-e49398b65980",
  LocationAnalyticsReportSectionName: "ReportSection46d80580e572ada4e609",

  //Dream Video
  CEODreamVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/6babe832-5810-4b06-baa9-81f01f472a31/NRF_Dream_Video_V08.ism/manifest",
  //Store Overview Video
  StoreVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/440da69f-c3e4-4537-ae28-8d05458c7e0b/NRF_Store_Video_V12.ism/manifest",
  //Final Video
  FinalVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/0defed2d-2acb-46cc-97f6-13b1e993f8e3/NRF_Finale_Video_V16.ism/manifest",

  //Real-time In-store Analytics
  RealTimeInStoreAnalyticsReportID: "adffccc8-eb71-4792-a149-85772fd53982",
  RealTimeInStoreAnalyticsReportSectionName:
    "ReportSection6efc74dccd4775687467",

  //North America Metrics
  gb_reportId: "9f427848-e893-46de-8de2-b42366b1c8ed",
  na_miami_ROA: "ReportSectionadbc2377f2c7b3656767",
  na_miami_CE: "ReportSection08315d1f93f102e213b0",
  na_miami_OP: "ReportSection5b59605333194e598a3b",
  na_Phoenix_ROA: "ReportSectionba94b291ede4db000f97",
  na_Phoenix_CE: "ReportSectionddb095ed184c1139b35c",
  na_Phoenix_OP: "ReportSectionbc399dbd86c00588e223",
  na_newyork_ROA: "ReportSection7dfc3d09b1e1b35991c3",
  na_newyork_CE: "ReportSectionf53b9ba997d6ed1498fa",
  na_newyork_OP: "ReportSectionf770091f8866c737d416",
  na_charlotte_ROA: "ReportSection2ab692f593997a54fa33",
  na_charlotte_CE: "ReportSection365a5fc783b3142fa5dd",
  na_charlotte_OP: "ReportSection1348a6087741e32baa20",
  na_losangeles_ROA: "ReportSection214bcb5067045602c099",
  na_losangeles_CE: "ReportSection44ea72362b0346de8753",
  na_losangeles_OP: "ReportSection21a46adfb3bb5d6a429c",

  //Stock Levels-ECO Department
  EcoDepartmentPageUrl: "https://app-nrf-zarmada-demo.azurewebsites.net/",

  //Demand By Location
  DemandByLocationReportID: "abe73723-9aec-4050-b42a-231145c5b198",
  DemandByLocationReportSectionName: "ReportSection",

  //Product Recommendations San Diego
  ProductRecommendationReportID: "b27c1ab0-273c-4677-bf33-fca41a420b1e",
  ProductRecommendationReportSectionName: "ReportSectionb1db078f436c6df90c30",

  CallCenterBeforeReportID : "bb1436c5-af3c-4b2a-b4eb-332b0c213a5f",
  CallCenterBeforeReportSectionName : "ReportSection75ed9de8b9e66a22c529",

  CallCenterAfterReportID : "40a3ee62-cba5-4092-b4fd-474f9f0cb274",
  CallCenterAfterReportSectionName : "ReportSection623b64746831c0065bc0",
};
