window.config = {
  BlobBaseUrl: 'https://healthcare.azureedge.net/',
  IconBlobBaseUrl: 'https://healthcare.azureedge.net/left-nav-icons/',

  APIUrl: 'https://app-health-care-demo-v2prod.azurewebsites.net',
  // APIUrl: 'https://localhost:5001',

  BingMapKey:
    'AhBNZSn-fKVSNUE5xYFbW_qajVAZwWYc8OoSHlH8nmchGuDI6ykzYjrtbwuNSrR8',
  PSSqlDashboardBefore_ID: '7e9f44c1-4405-480e-8195-85a41022a7b8',
  PSSqlDashboardDuring_ID: '73110aee-e6d1-434e-86f6-e953ccc020c7',
  PSSqlDashboardAfter_ID: '36892896-3444-4073-a841-940c62be64dd',

  PDFblobInput:
    'https://stincidentsearch001.blob.core.windows.net/hospitaldatapdf/',
  PDFblobOutput:
    'https://stincidentsearch001.blob.core.windows.net/hospitaldata/',

  PSSqlEmbeddedDashboardBefore_ID: '216b12ce-7aa2-4d31-b281-7f814654da25',
  PSSqlEmbeddedDashboardDuring_ID: '46d85920-ae56-437a-8343-4310a66d0225',
  PSSqlEmbeddedDashboardAfter_ID: 'cdd7fb69-cc00-4d9d-ad35-eaa2ab4de6fa',

  PSAfterDashBoard_ID: '',
  // PSAfterDashBoard_ID: "a34a7bea-53cf-41da-b2e7-5f5d5ecd006e",
  PSBeforeDashBoard_ID: '1505bbe6-0477-4148-a925-6543d9192de0',
  PSDuringDashBoard_ID: '73110aee-e6d1-434e-86f6-e953ccc020c7',

  // Used in app/pages/AfterDashboard
  AfterDashBoard_ID: '882bc57e-247f-4b55-aced-dbfd63fc27be',

  // Used in app/pages/AnomalyDetectionReport
  AnomalyDetectionReport_ID: '030028de-3064-4a9d-af96-a24f4de0a713',
  AnomalyDetectionReport_NAME: 'ReportSectiona98bb2fcc5ef8d9b383c',

  // Used in app/pages/campaignreport
  EmbeddedCampaignDashboard_ID: 'b58e0d14-6031-4fde-9eb6-f16d7603b6dc',
  EmbeddedCampaignDashboard_NAME: 'ReportSection01004f62b9c010350168',

  // Used in app/pages/CampaignReport
  campaignReport_ID: '2d3851fc-0001-43c3-9e97-715ab963e621',

  // Used in app/pages/ecommerce
  ecommercIframeSrc: 'https://wideworldimporters-mfg.azurewebsites.net/',

  // Used in app/pages/Factory
  fc_reportId: '8758aa7c-fbec-4c14-a09d-ae69d318e571',
  fc_overview: 'ReportSection5691aa74d544b03cf6ed',
  fc_alert: 'ReportSectiond6c63aee8dbd98c9083f',
  fc_production: 'ReportSectionac4bd6f209518e10476c',
  fc_oee: 'ReportSection',
  fc_downtime: 'ReportSection3c5e87c973012471344a',
  fc_energyMaintenance: 'ReportSectiondeef76048dca20b20db0',

  // Used in app/pages/hospitalinsights
  finance_ID: '696a867c-346e-436e-b4e5-c4af47c52f98',

  // Used in app/pages/FormRecognizer
  // PDFBaseLink: "https://stcognitivesearch001.blob.core.windows.net/incidentreport/",
  PDFBaseLink:
    'https://apps.powerapps.com/play/e2fdb295-efde-428b-b082-f579fb003b93?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a',
  // https://app.powerbi.com/groups/7dbcb1b3-d1b5-4c76-80bc-ebba6dcaeabb/dashboards/bdd559db-e7b9-47f2-aca8-0d1b8b34d410?noSignUpCheck=1
  ad_reportid: 'bdd559db-e7b9-47f2-aca8-0d1b8b34d410',
  ad_reportSection: 'ReportSectionb1b83158629eb8d50354',

  // Used in app/pages/GlobalBing
  gb_reportId: 'dfea6cef-9822-41f0-9916-4de69bebdeba',

  gb_marginId_Honolulu: 'ReportSection2ab692f593997a54fa33',
  gb_bedOccupancyId_Honolulu: 'ReportSection365a5fc783b3142fa5dd',
  gb_patientExpId_Honolulu: 'ReportSection1348a6087741e32baa20',

  gb_marginId_Miami: 'ReportSectionadbc2377f2c7b3656767',
  gb_bedOccupancyId_Miami: 'ReportSection08315d1f93f102e213b0',
  gb_patientExpId_Miami: 'ReportSection5b59605333194e598a3b',

  gb_marginId_Chicago: 'ReportSection8017c7243b47176352ae',
  gb_bedOccupancyId_Chicago: 'ReportSectioncd40a1a6ddca5c21d659',
  gb_patientExpId_Chicago: 'ReportSection1be018e5d3e8518e00a8',

  gb_marginId_Anchorage: 'ReportSectionba94b291ede4db000f97',
  gb_bedOccupancyId_Anchorage: 'ReportSectionddb095ed184c1139b35c',
  gb_patientExpId_Anchorage: 'ReportSectionbc399dbd86c00588e223',

  gb_marginId_LosAngeles: 'ReportSection7dfc3d09b1e1b35991c3',
  gb_bedOccupancyId_LosAngeles: 'ReportSectionf53b9ba997d6ed1498fa',
  gb_patientExpId_LosAngeles: 'ReportSectionf770091f8866c737d416',

  // Used in app/pages/globalsafetydashboard :
  gsd_reportid: '030028de-3064-4a9d-af96-a24f4de0a713',
  gsd_reportSection: 'ReportSectionc421a149d479899127e8',

  // Used in app/pages/Machine
  mach_reportId: '525f3fab-3c17-4223-8c5e-2bdff2e27ef1',
  mach_vibrations: 'ReportSection8f78bb77c041cc954390',
  mach_movements: 'ReportSection66a414177b81ec5e9996',
  mach_temperature: 'ReportSectiond9ce432c4ebc9150bd34',
  mach_anomolyReportID: 'a8ac25dc-6c75-486d-970e-feddb9d0d6fb',
  mach_anomolyReportSection: 'ReportSection070fb616c2ef645c8fc6',
  mach_htapReportID: '59109511-9f36-42dc-be20-03746cc271ea',
  mach_withoutHtapReportSection: 'ReportSection7cb15bccee28f85ee6c5',
  mach_withHtapReportSection: 'ReportSection0f90f2085202f027fc13',
  mach_ctScanReportId: '4bd570fc-0bee-4699-a784-d581c7618325',

  // Use in app/pages/SlaesCampaginReportPostMigration => hospital insights
  salesAndCampaign_first: '93104d32-f4c7-4aeb-90bb-e26dc3f759a7',
  salesAndCampaign_second: '',

  // Use in app/pages/PowerApps
  powerAppsSrc:
    'https://apps.powerapps.com/play/38a611ae-72fc-4719-bea4-b003709179f2?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a&source=portal&screenColor=rgba(37%2C%2062%2C%20143%2C%201)',
  // powerAppsSrcFormRecongnise: "https://apps.powerapps.com/play/b956359e-ce8c-43e0-94f0-ca2116be398d?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a&source=portal&screenColor=rgba(1%2C%20131%2C%20134%2C%201)",
  powerAppsSrcFormRecongnise:
    'https://apps.powerapps.com/play/4b1c09b5-d1c3-4c26-97ae-7b29529f11ec?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a&source=portal&screenColor=rgba(37%2C%2062%2C%20143%2C%201)',

  // apiUrl: "https://demohealthcare.azurewebsites.net",
  apiUrl2: 'https://manufacturingdemopoc.azurewebsites.net',

  dashboardIdInMenu: '92341384-7fc2-44d4-b36e-9c99102d57f9',

  // Used in azure form recognizer
  PDFblobInput:
    'https://stincidentsearch001.blob.core.windows.net/hospitaldatapdf/',
  PDFblobOutput:
    'https://stincidentsearch001.blob.core.windows.net/hospitaldata/',

  searchIndex: 'osha-formrecogoutput-index',
  searchQueryKey: '7F39D874A56C34CF57B59DBC72B2B4BA',
  searchService: 'askmworkshop',

  // Used in /healthcare-anlaytics
  HealthcareAnalyticsReport_NAME: 'ReportSectionef85486749253cd45508',
  HealthcareAnalyticsReport_ID: 'c3746e5d-c5ae-43ec-8719-cd4ff86afba1',

  // Used in /hospital-incident
  HospitalIncidentReport_ID: '4182c5a4-6466-4cae-94c3-74960363f5c4',
  HospitalIncidentReport_Name: 'ReportSection',

  WorldMapReportID: 'f75381cc-ed65-43dd-8f0a-1a542bbfd69e',
  WorldMapReportSectionName: 'ReportSection',

  Dynamic365VideoLink:
    'https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/b922cfb0-c9a5-4f3f-bf90-164ba7fb7558/Demo Clip for d365.ism/manifest',

  HospitalInsightsDashboardID: 'a51a18a7-a399-4d75-86e0-1b91b303a970',

  HospitalInsightsReportID: 'bf721a96-c85c-4c89-8c65-5e7f0c4f7bbb',
  HospitalInsightsReportSectionName:
    'ReportSectionff14e21bdad140901345?experience=power-bi',

  WithoutAzureSynapseLinkReportId: '1b4e0385-4ab5-4005-83c8-59e3f2f28050',
  WithoutAzureSynapseLinkReportSection_Name:
    'ReportSection7cb15bccee28f85ee6c5',

  WithAzureSynapseLinkReportId: '1b4e0385-4ab5-4005-83c8-59e3f2f28050',
  WithAzureSynapseLinkReportSection_Name: 'ReportSection0f90f2085202f027fc13',

  PredictiveAnalyticsReport_ID: 'f0d4892e-675b-4159-b122-3de234419bdb',
  PredictiveAnalyticsReportSection_Name: 'ReportSection01004f62b9c010350168',

  HealthHubReportID: '0b33f9dc-82b6-43ac-a8e2-8e1a9e27bcb9',
  HealthHubReportSectionName:
    'ReportSection150361fdd687f60e02fd?experience=power-bi',

  HealthSearchUrl:
    'https://app-health-search.azurewebsites.net/home/index?q=cough,fever',

  HoloLensVideo:
    'https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/c3df01ba-6b90-423e-a92b-474d163073ac/MICROSOFT HEALTH CARE HOLOLENS D.ism/manifest',

  FinaleVideoUrl:
    'https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/acc875b7-4542-4a58-a0f4-f2940285e486/Healthcare_Finale_V014.ism/manifest',

  BedOccupancyReportID: '6140ddd5-9c63-4078-8d3d-ca9a9084b633',
  BedOccupancyReportSectionName: 'ReportSectionae2997831bfa33b8ebcc',

  PatientProfileReportID: '6602e1b2-1226-43c9-afa5-24b0b7cd0fc7',
  PatientProfileReportSectionName: 'ReportSection9e01a639d7f27865119c',

  PayorExecutiveDashboardID: 'a855ace9-5e3c-4e9d-9502-94e7c5d0f1bd',

  PatientDetailsReportID: 'c75cfcbb-f0ce-4926-9e6c-8c133aa5c9e5',
  Hemoglobin: 'ReportSection292b41347d19287d5d88',
  Glucose: 'ReportSection1ec1b764313aeed43736',
  Erythrocytes: 'ReportSection569e881b9d4421f4464e',
  Carbondioxide: 'ReportSection5f3c9683e12295770f19',
  TopTable: 'ReportSection19162b2a3c69555a0eac',
  Details: 'ReportSection9eb6962e6e432a8f078d',

  BeforeCallCenterReportID: 'd75b88cb-eac8-4250-bfff-dbb3e7c10caf',
  BeforeCallCenterSectionName: 'ReportSectionda209890a7f0f9e42736',

  AfterCallCenterReportID: '026d0b4e-f899-42b4-a2b7-fbdea3de02ca',
  AfterCallCenterSectionName: 'ReportSection623b64746831c0065bc0',

  AfterCallCenterSummaryReportID: '026d0b4e-f899-42b4-a2b7-fbdea3de02ca',
  AfterCallCenterSummarySectionName: 'ReportSectionda209890a7f0f9e42736',

  ClinicalNotesUrl:
    'https://app-clinical-notes.azurewebsites.net/#/fce90956-57be-4ec8-ad68-dccfc5129ad1',

  chat_bot_url:
    'https://webchat.botframework.com/embed/customchatbot-qa?s=DQbIjAyhZqE.3tOVkQ9ecerNmoEjeYrvHBp16kuOMi0ShdYOacuuKnc',

  OpenAIChatBotUrl: 'https://app-healthcare-openai.azurewebsites.net/',

  PayorExecutiveDashboardAfterID: '5d9ffeb9-8170-47d9-b4eb-ff610fd74b1a',

  ChatBotDatabricksLink:
    'https://ml.azure.com/?tid=f94768c8-8714-4abe-8e2d-37a64b18216a&wsid=/subscriptions/506e86fc-853c-4557-a6e5-ad72114efd2b/resourcegroups/rg-healthcare2-prod/providers/Microsoft.MachineLearningServices/workspaces/mlw-healthcare2-prod',

  BreakDownReportID: '5513523b-1f33-4351-8f06-c764b7051d89',
  BreakDownReportSectionName: 'ReportSection9e01a639d7f27865119c',

  KeyInfluencersReportID: '5513523b-1f33-4351-8f06-c764b7051d89',
  KeyInfluencersReportSectionName: 'ReportSection174cf9bdb5abf0cbb38b',

  RevenueReportID: 'b58e0d14-6031-4fde-9eb6-f16d7603b6dc',
  RevenueReportSectionName: 'ReportSection8b6d7b1114bebe685058',

  AfterRevenueReportID: 'b58e0d14-6031-4fde-9eb6-f16d7603b6dc',
  AfterRevenueReportSectionName: 'ReportSection4d451771c3d80c0b68d8',

  BedOccupancyExternalLink:
    'https://web.azuresynapse.net/en/home?workspace=%2fsubscriptions%2f506e86fc-853c-4557-a6e5-ad72114efd2b%2fresourceGroups%2frg-healthcare2-prod%2fproviders%2fMicrosoft.Synapse%2fworkspaces%2fsynhealthcare2prod',

  SinglePatientReportID: 'b4a2cf06-2f7d-4cfd-ba1a-6ba42a931a96',

  SystolicReportSectionName:
    'ReportSection8f0ba99268a46e29e619?experience=power-bi',
  Spo2ReportSectionName: 'ReportSection?experience=power-bi',
  HeartrateReportSectionName:
    'ReportSection8f0ba99268a46e29e619?experience=power-bi',
};
